function bidPuppy() {
	if (timer > 0) {
	var bid = document.getElementById('currentbid').innerHTML;
	var currentBid = Number(bid);
	currentBid = currentBid + 1;
	document.getElementById('currentbid').innerHTML = currentBid.toString();
	var bidder = document.getElementById('bidName').value;
	document.getElementById('currentWinner').innerHTML = bidder;
	}
}

var timer = 60;
var timerVariable = setInterval(myTimer, 1000);


function myTimer() {
    
    document.getElementById("timeremaining").innerHTML = timer;
    timer = timer - 1;

    if (timer < 0) {
    	window.clearInterval(timerVariable);	
    }
}
